from breezypythongui import EasyFrame
import assignments
import student
import time_management

def assignment_properties(input_line):
    line=line.split(';')
    assignment_type=line[0]
    assignment_dict={}
    for part in line[1].split('|'):
        key,value=part.split('^')
        assignment_dict[key]=value
    return(assignment_type,assignment_dict)

class Scheduler(EasyFrame):
    def __init__(self):
        self.assignments_list=[]
        try:
            open("assignments_list.txt", 'x')
        except:
            test = 1
        #self.loadassignments_list(self.assignments_list) 
        EasyFrame.__init__(self, title="Help Me Procrastinate")
        self.setBackground("#8B0000")
        self.addLabel(text="Assignment Name: ",
                      row=0, column=0)
        self.assignmentnameField = self.addTextField(text="",
                                                row = 0,
                                                column = 1)
        self.addLabel(text="Due Date: ",
                      row=1, column=0)
        self.due_dateField = self.addTextField(text="",
                                                row=1,
                                                column=1)
        self.addLabel(text="Professor Name: ",
                      row=2, column=0)
        self.profField = self.addTextField(text="",
                                            row=2,
                                            column=1)

        self.addLabel(text="Hours Required: ",
                      row=3, column=0)
        self.hoursField = self.addFloatField(value=0, row=3, column=1)

        self.addLabel(text="Pages: ",
                      row=2, column=2)
        self.pagesField = self.addFloatField(value=0, row=2, column=3)

        self.addLabel(text="Citations: ",
                      row=1, column=2)
        self.researchField = self.addFloatField(value = 0,
                                                row=1,
                                                column=3)
        self.addLabel(text="Words: ",
                      row=0, column=2)
        self.wordsField = self.addFloatField(value = 0,
                                            row=0,
                                            column=3)
        self.addLabel(text="Questions: ",
                      row=3, column=2)
        self.questionsField = self.addFloatField(value=0, row=3, column=3)

        self.group = self.addRadiobuttonGroup(row=5, column=0,
                                              columnspan=4)
        defaultRB = self.group.addRadiobutton("Self Learning")
        self.group.addRadiobutton("Reading")
        self.group.addRadiobutton("Writing")
        self.group.addRadiobutton("Other")
        self.group.setSelectedButton(defaultRB)
        self.addButton(text = "  Delete  ", row = 6, column = 2,
                       command = self.deleteAssignment)
        self.addButton(text = "   Save  ", row = 6, column = 1,
                      command = self.saveAssignment)
        self.addButton(text = "  View   ", row = 6, column = 0,
                       command = self.viewAssignment)
        self.AssignmentEntry = self.addTextArea("", row = 7, column = 0,
                                             columnspan = 6,
                                             width = 75, height = 10)
        self.addButton(text = "  Exit  ", row = 9, column = 3,
                      command = self.exitScheduler)

    def viewAssignment(self):
        count = 0
        oField = "Assignment List\n"
        oField += "%-20s%-20s%-20s%-20s\n" % ("Assignment Name", "Due Date", "Professor Name", "Scheduled Start")
        while(count < len(self.assignments_list)):
                name = self.assignments_list[count].returnnameField()
                due_date = self.assignments_list[count].returndue_dateField()
                professor = self.assignments_list[count].returnprofField()
                scheduled_start = self.assignments_list[count].returnscheduled_startField()
                (name, due_date, professor, scheduled_start)
                count += 1
        self.AssignmentEntry.setText(oField)                              

    def saveAssignment(self):
        assignmentFile = open("assignments_list", 'w')
        for Assignment in self.assignments_list:
            sect = Assignment.returnassignmentname() + " "
            sect += Assignment.returndue_date() + " "
            sect += Assignment.returnprof() + " "
        assignmentFile.close()     

    def deleteAssignment(self):
        count = 0
        assignment_name = self.assignmentnameField.getText()
        while(count < len(self.assignments_list)):
            assignmentName = self.assignments_list[count].returnAssignment()
            if(assignment_name == assignmentnameField):
                self.assignments_list.pop(count)
                self.clearField()
                break

    def clearField(self):
        self.assignmentnameField.setText("")
        self.due_dateField.setText("")
        self.profField.setText("")
        self.hoursField.setText("")
        self.pagesField.setText("")
        self.researchField.setText("")
        self.wordsField.setText("")
        self.questionsField.setText("")
        self.clearField()

    def exitScheduler(self):
        exit()

def main():
    Scheduler().mainloop()
if __name__ == "__main__":
    main()


