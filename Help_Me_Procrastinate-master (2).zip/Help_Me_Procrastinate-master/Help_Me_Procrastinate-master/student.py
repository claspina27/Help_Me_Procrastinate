
class Student(object):
    def __init__(self, name,read,write,research,questions):
        self.name = name
        self.read_speed = read
        self.write_speed = write
        self.research_rate = research
        self.questions_per_min = questions

