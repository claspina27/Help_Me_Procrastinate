import os
import sys
import include.gui

def main():
    include.gui.Scheduler().mainloop()
if __name__ == "__main__":
    main()
